
const isEven = require('is-even-check-new');
console.log(isEven(4)); // true
console.log(isEven(5)); // false
