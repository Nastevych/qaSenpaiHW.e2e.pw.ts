import { test, expect } from '@playwright/test';
//#region
const Email = "borysplaton.test@gmail.com";
const Password = "123456789";
//#endregion

  test.beforeEach(async ({ page }) => {
    await page.goto('https://test.askod.online:60204');
    const SignUpButton = page.locator('');
  });

  test('fill login page', async ({ page }) => {
    //#region
    const emailField = page.locator(`//input[@name="email"]`);
    const passwordField =  page.locator(`//input[@name="password"]`);
    const submitButton =  page.locator(`//button[@type="submit"]`);
    const rememberMeCheckBox = page.locator(`.v-input--selection-controls__ripple`); //input[@role="checkbox"]
    //#endregion

    await emailField.fill(Email);
    await passwordField.fill(Password);
    await rememberMeCheckBox.click();
    await submitButton.click();
        
    // await expect(page)
    // .toHaveURL('https://test.askod.online:60204');
      
    });