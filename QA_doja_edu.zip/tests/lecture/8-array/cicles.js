const fruits = ['apple', 'banana', 'orange'] 

for (const fruit of fruits){
    console.log(fruit);
};

fruits.forEach(function(fruit, index, array){
    console.log(fruit);
});

// declaration
//hosting - можна викликати де завгодно
function isArr (){};

// function expression (фнкціональний вираз)



const generateNme = function(){
    console.log('3333');
};


generateNme();

// arrow function

const sayHi = (param1, param2) => {
    console.log("H");
    console.log(param1);
    console.log(param2);
}

sayHi('Pavlo', 'Ash');