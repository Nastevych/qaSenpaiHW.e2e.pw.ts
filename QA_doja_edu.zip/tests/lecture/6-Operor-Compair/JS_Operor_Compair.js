const a =11;
const b = 11;
console.log(a > b);
console.log(a < b);
console.log(a >= b);
console.log(a <= b);

console.log(a == b);
console.log(a === b);

console.log(a !== b);


const temp = 10;

if(temp >=15){
    console.log('Вєтровка')
}

if(temp <15){
    console.log('кофту = вєтровку')
}

// 


let hasTicket = false;

if (hasTicket === true){
    console.log('pass')
}

if (hasTicket === false){
    console.log('do not pass')
}

if (hasTicket){
    console.log('pass')
}

if (!hasTicket){
    console.log('do not pass')
}

if (hasTicket){
    console.log('pass')
} 
else {
    console.log('do not pass')
}

//

let questAge = 20;

if (questAge >= 18){
    console.log('give alcohol')
} 
else {
    console.log('do not give alcohol')
}
