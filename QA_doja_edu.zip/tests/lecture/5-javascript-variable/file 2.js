var somevariable = 'afsdfsdsdg';
var somevariable = 'afsdfsdfdgdgdfgsdg';

console.log(somevariable);

let someLetVariable = '333333';
someLetVariable = '3343534543333';

const someConstVariable = 'ssdgdfsgdfgffg';
//someConstVariable = '4444';
console.log(someConstVariable);

// область видимості

//глобальна
let someBlochVariable2 =123455;
if(true){
    console.log(someBlochVariable2);
    };
    console.log(someBlochVariable2);

//блочна
if(true){
let someBlochVariable =123455;
console.log(someBlochVariable);
};
console.log(someBlochVariable);

//функціональна

function fizz(){
    let someFuncVariable = 'some vars';
    console.log(someFuncVariable);  
};
//лексична
