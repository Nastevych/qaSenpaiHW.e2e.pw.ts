console.log("Hello word!!");
console.log('');

console.log(1234523);
//tyoeof повертає тип даний який був переданий
console.log(typeof 1241);

// число
const num = 11_05_93;
const pi = 3.14;
const minuspi = -3.14;
console.log(num);
console.log(minuspi);

console.log(10/0);
console.log('a' * 2);


//sting (рядок)

const str_1 = 'Hello, world!!';
const str_2 = "";

console.log(" ' ' ");
console.log('Hello, world!!');

//string templating (шаблони рядків)

const str_3 = ` 
test 
${str_1}
test
" `;
console.log(str_3);

// boolean / логічне значення
let isTrue = true;
let isFalse = false;

// undefine не визначений
let undef;

console.log(undef);

// null порожнє
let n= null;
console.log(n);
console.log(typeof n);

//symbol

let sym = Symbol('some description sdfgsdfg');
console.log(sym);
console.log(typeof sym);


// BigInt (ES11)

let someBigInt = 123456789001234455678989889n;

console.log(someBigInt);
console.log(typeof someBigInt);

// object 

const obj = {x: 'qa dojo', xaxa: 'ddddd', num: 333333};
const some = obj;
obj.x = 'this is qa dojo';

console.log(obj);
console.log(some);

// місиви array
const someArray = [1,2,3,4, 'dddd', 1232323, 'dfdsf'];
console.log(someArray[0]);