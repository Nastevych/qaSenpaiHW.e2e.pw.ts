import {test, expect, chromium}from "@playwright/test";

test ("test1", async () => {
    const browser = await chromium.launch ({headless: false});

    const context = await browser.newContext();

    const page = await context.newPage();

    console.log("stats");
});

// fixture

test ("test2", async ({ page }) => {
    await page.goto("https://coffee-cart.app");

    await page.locator("//div[@class = '11']").click();
    });
