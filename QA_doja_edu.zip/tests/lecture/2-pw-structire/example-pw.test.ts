import {test, expect } from '@playwright/test'

test("promotion massage buttons showed", async ({ page }) => {
  await page.goto("https://coffee-cart.app/");
 
  const espresso = page.locator ('[data-test="Espresso"]');

  await espresso.click({button: 'right', clickCount: 1, delay: 500});

  await espresso.fill('', {force:false});

  await page.locator('[data-test="Espresso"]').click();
  await page.locator('[data-test="Espresso_Macchiato"]').click();
  await page.locator('[data-test="Espresso"]').click();
  
  await expect(
    page.getByRole('button', { name: 'Yes, of course!' })
    ).toBeVisible();
  
  await expect(
    page.getByRole('button', { name: 'Nah, I\'ll skip.' })
    ).toBeVisible();
});