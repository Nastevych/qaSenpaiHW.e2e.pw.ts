import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('http://the-internet.herokuapp.com/login');

  await page.getByText("Username", {exact: true});

  await page.getByLabel('Username').click();
  
  await page.getByRole('textbox', { name: 'Username' }).click();

  await page.getByPlaceholder('');

  await page.getByAltText('');
  
  await page.getByTitle('');

  await page.getByTestId('');

});