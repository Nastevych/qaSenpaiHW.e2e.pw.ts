for(let i = 0; i < 9; i++){
    console.log(i)
}

//

let i = 1;

while(i > 0){
    console.log(i);
    i--
}

//

do{ console.log(i);
    i--}
while (i > 1);

//

const numbess = [1, 2, 3, 4, 5, 6, 7 ,8 ,9, 10].forEach((number)=>{
    number++;
    console.log(number);
});

//


const numbers = [1, 2, 3, 4, 5, 6, 7 ,8 ,9, 10];

for (let number of numbers){
    number++
    console.log(number);
};

//

const someObj = {
    i:1,
    b:2,
    c:3
};

for(const key in someObj){
    console.log(key);
    console.log(someObj);
};