function sayHi(name){
 const greetings = `Hello, my name is ${name}`;
 console.log(greetings);
};

sayHi(`Pavlo`);
sayHi(`Oleg`);
sayHi(`Lena`);
console.log(greetings);
